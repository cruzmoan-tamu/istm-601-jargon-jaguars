"""yourpkg: example package that uses pandas."""
__all__ = ["core"]
__version__ = "0.1.0"
